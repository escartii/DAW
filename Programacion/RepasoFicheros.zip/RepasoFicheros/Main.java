import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Main {
    public static void main(String[] args) {
        try (BufferedReader br = new BufferedReader(new FileReader("Usuarios.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.contains("grado,edad")) {
                    String[] str = line.split(",");
                    String name = str[1];
                    String apellido = str[2];
                    String grado = str[3];
                    int edad = Integer.parseInt(str[4]);

                    try (
                        Connection conexion = ClaseConectar.conectar()){
                        String query = "INSERT INTO pruebas.Usuarios (nombre, apellido, grado, edad) VALUES (?, ?, ?, ?)";
                        try (PreparedStatement pstmt = conexion.prepareStatement(query)) {
                            pstmt.setString(1, name);
                            pstmt.setString(2, apellido);
                            pstmt.setString(3, grado);
                            pstmt.setInt(4, edad);
                            pstmt.executeUpdate();
                        }
                    } catch (SQLException e) {
                        System.err.println("Error executing query: " + e.getMessage());
                    }

                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }
}