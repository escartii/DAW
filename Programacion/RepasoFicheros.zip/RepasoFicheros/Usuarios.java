public class Usuarios {

    private int id_usuario;
    private String nombre;
    private String apellidos;
    private String grado;
    private int edad;

    public Usuarios(String nombre, String apellidos, String grado, int edad) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.grado = grado;
        this.edad = edad;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

}
