import java.sql.*;

public class ExtraerDatos {
    // JDBC URL, username y password de MySQL
    static final String JDBC_URL = "jdbc:mysql://localhost/pruebas";
    static final String JDBC_USER = "tu_usuario";
    static final String JDBC_PASSWORD = "tu_contraseña";

    public static void main(String[] args) {
        try {
            // Registra el driver JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Abre la conexión
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);

            // Crea el statement
            Statement stmt = conn.createStatement();

            // Ejecuta la consulta SQL
            String sql = "SELECT * FROM Usuarios";
            ResultSet rs = stmt.executeQuery(sql);

            // Itera sobre los resultados y muestra los datos
            while (rs.next()) {
                int id = rs.getInt("id_usuario");
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                String grado = rs.getString("grado");
                int edad = rs.getInt("edad");

                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Apellido: " + apellido + ", Grado: " + grado + ", Edad: " + edad);
            }

            // Cierra la conexión
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
