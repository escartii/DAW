<?php
/**
 * The template for displaying the footer
 * @subpackage Ultra Print
 * @since 1.0
 * @version 0.1
 */

?>
	<div class="footerwavey">
		<svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;"><path d="M-46.84,237.33 C158.01,-239.30 496.05,413.97 540.06,-204.77 L500.00,150.00 L183.41,155.42 Z" style="stroke: none; "></path></svg>
				
	</div>
	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="container">
			<?php get_template_part( 'template-parts/footer/footer', 'widgets' ); ?>
			<div class="footer-wavey">
				<svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;"><path d="M-7.34,-13.31 C86.90,156.41 121.89,16.28 194.13,159.38 L142.21,151.47 L0.00,150.00 Z" style="stroke: none;"></path></svg>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="copyright"> 
			<div class="container">
				<?php get_template_part( 'template-parts/footer/site', 'info' ); ?>
			</div>
		</div>
		<svg class="footer-circle" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
			<defs>
				<clipPath id="cut-off-bottom">
					 <rect x="0" y="0" width="200" height="80"></rect>
				</clipPath>
			</defs>
			<circle cx="100" cy="100" r="100" clip-path="url(#cut-off-bottom)"></circle>
		</svg>
		<svg class="footer-circlesmall" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
			<defs>
				<clipPath id="cut-off-bottom">
					<rect x="0" y="0" width="100" height="80"></rect>
				</clipPath>
			</defs>
		<circle cx="80" cy="80" r="40" clip-path="url(#cut-off-bottom)"></circle>
		</svg>
	</footer>
	<?php if (get_theme_mod('ultra_print_show_back_totop',true) != ''){ ?>
		<button role="tab" class="back-to-top"><span class="back-to-top-text"><?php echo esc_html('Top', 'ultra-print'); ?></span></button>
	<?php }?>

<?php wp_footer(); ?>
</body>
</html>