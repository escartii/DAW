<?php
/**
 * Displays footer site info
 *
 * @subpackage Ultra Print
 * @since 1.0
 * @version 1.4
 */

?>
<div class="site-info">
	<a href="<?php echo esc_html(get_theme_mod('ultra_print_footer_link',__('https://www.luzuk.com/themes/free-printing-wordpress-theme/','ultra-print'))); ?>" target="_blank">
		<p><?php echo esc_html(get_theme_mod('ultra_print_footer_copy',__('Printing WordPress Theme By Luzuk','ultra-print'))); ?></p>
	</a>
</div>