<?php 

	$ultra_print_custom_style = '';

	// Logo Size
	$ultra_print_logo_top_padding = get_theme_mod('ultra_print_logo_top_padding');
	$ultra_print_logo_bottom_padding = get_theme_mod('ultra_print_logo_bottom_padding');
	$ultra_print_logo_left_padding = get_theme_mod('ultra_print_logo_left_padding');
	$ultra_print_logo_right_padding = get_theme_mod('ultra_print_logo_right_padding');

	if( $ultra_print_logo_top_padding != '' || $ultra_print_logo_bottom_padding != '' || $ultra_print_logo_left_padding != '' || $ultra_print_logo_right_padding != ''){
		$ultra_print_custom_style .=' .logo {';
			$ultra_print_custom_style .=' padding-top: '.esc_attr($ultra_print_logo_top_padding).'px;
			padding-bottom: '.esc_attr($ultra_print_logo_bottom_padding).'px;
			padding-left: '.esc_attr($ultra_print_logo_left_padding).'px;
			padding-right: '.esc_attr($ultra_print_logo_right_padding).'px;';
		$ultra_print_custom_style .=' }';
	}

	// section padding
	$ultra_print_about_section_padding = get_theme_mod('ultra_print_about_section_padding');

	if( $ultra_print_about_section_padding != ''){
		$ultra_print_custom_style .=' #about-section {';
			$ultra_print_custom_style .=' padding-top: '.esc_attr($ultra_print_about_section_padding).'px;
				padding-bottom: '.esc_attr($ultra_print_about_section_padding).'px;';
		$ultra_print_custom_style .=' }';
	}

	// Site Title Font Size
	$ultra_print_site_title_font_size = get_theme_mod('ultra_print_site_title_font_size');
	if( $ultra_print_site_title_font_size != ''){
		$ultra_print_custom_style .=' .logo h1.site-title, .logo p.site-title {';
			$ultra_print_custom_style .=' font-size: '.esc_attr($ultra_print_site_title_font_size).'px;';
		$ultra_print_custom_style .=' }';
	}

	$ultra_print_site_title_color = get_theme_mod('ultra_print_site_title_color');

	if ( $ultra_print_site_title_color != '') {
		$ultra_print_custom_style .=' h1.site-title a, p.site-title a {';
			$ultra_print_custom_style .=' color: '.esc_attr($ultra_print_site_title_color).' !important;';
		$ultra_print_custom_style .=' }';
	}

	// Site Tagline Font Size
	$ultra_print_site_tagline_font_size = get_theme_mod('ultra_print_site_tagline_font_size');
	if( $ultra_print_site_tagline_font_size != ''){
		$ultra_print_custom_style .=' .logo p.site-description {';
			$ultra_print_custom_style .=' font-size: '.esc_attr($ultra_print_site_tagline_font_size).'px;';
		$ultra_print_custom_style .=' }';
	}

	$ultra_print_site_tagline_color = get_theme_mod('ultra_print_site_tagline_color');

	if ( $ultra_print_site_tagline_color != '') {
		$ultra_print_custom_style .=' p.site-description {';
			$ultra_print_custom_style .=' color: '.esc_attr($ultra_print_site_tagline_color).';';
		$ultra_print_custom_style .=' }';
	}

	// Copyright padding
	$ultra_print_copyright_padding = get_theme_mod('ultra_print_copyright_padding');

	if( $ultra_print_copyright_padding != ''){
		$ultra_print_custom_style .=' .site-info {';
			$ultra_print_custom_style .=' padding-top: '.esc_attr($ultra_print_copyright_padding).'px; padding-bottom: '.esc_attr($ultra_print_copyright_padding).'px;';
		$ultra_print_custom_style .=' }';
	}

	// slider CSS
	$ultra_print_slider_hide_show = get_theme_mod('ultra_print_slider_hide_show',false);
	if( $ultra_print_slider_hide_show == true){
		$ultra_print_custom_style .=' .page-template-custom-home-page .inner-header {';
			$ultra_print_custom_style .=' display:none;';
		$ultra_print_custom_style .=' }';
	} else {
		$ultra_print_custom_style .=' #our-services .service-box {';
			$ultra_print_custom_style .=' margin: 20px 0 0;';
		$ultra_print_custom_style .=' }';
		$ultra_print_custom_style .=' #our-services .fertured-wave {';
			$ultra_print_custom_style .=' display:none;';
		$ultra_print_custom_style .=' }';
	}
	$ultra_print_slider_color = get_theme_mod('ultra_print_slider_color');

	if ( $ultra_print_slider_color != '') {
		$ultra_print_custom_style .='  #slider .inner_carousel h2 a, #slider .inner_carousel p {';
			$ultra_print_custom_style .=' color: '.esc_attr($ultra_print_slider_color).';';
		$ultra_print_custom_style .=' }';
	}

	//top
	$ultra_print_button_text_color = get_theme_mod('ultra_print_button_text_color');
	$ultra_print_button_bg_color = get_theme_mod('ultra_print_button_bg_color');

	if ( $ultra_print_button_text_color != '') {
		$ultra_print_custom_style .='  .quote-btn a {';
			$ultra_print_custom_style .=' color: '.esc_attr($ultra_print_button_text_color).'; background-color: '.esc_attr($ultra_print_button_bg_color).';';
		$ultra_print_custom_style .=' }';
	}

	//service
	$ultra_print_service_color = get_theme_mod('ultra_print_service_color');

	if ( $ultra_print_service_color != '') {
		$ultra_print_custom_style .=' .service-content h3 a {';
			$ultra_print_custom_style .=' color: '.esc_attr($ultra_print_service_color).';';
		$ultra_print_custom_style .=' }';
	}

	$ultra_print_service_img_color = get_theme_mod('ultra_print_service_img_color');

	if ( $ultra_print_service_img_color != '') {
		$ultra_print_custom_style .=' .service-img {';
			$ultra_print_custom_style .=' color: '.esc_attr($ultra_print_service_img_color).';';
		$ultra_print_custom_style .=' }';
	}

	//About
	$ultra_print_about_color = get_theme_mod('ultra_print_about_color');

	if ( $ultra_print_about_color != '') {
		$ultra_print_custom_style .=' .about-content h3, .about-content p {';
			$ultra_print_custom_style .=' color: '.esc_attr($ultra_print_about_color).';';
		$ultra_print_custom_style .=' }';
	}

	$ultra_print_aboutbtn_color = get_theme_mod('ultra_print_aboutbtn_color');
	$ultra_print_aboutbtnbg_color = get_theme_mod('ultra_print_aboutbtnbg_color');

	if ( $ultra_print_aboutbtn_color != '') {
		$ultra_print_custom_style .=' .about-btn a {';
			$ultra_print_custom_style .=' color: '.esc_attr($ultra_print_aboutbtn_color).'; background-color: '.esc_attr($ultra_print_aboutbtnbg_color).';';
		$ultra_print_custom_style .=' }';
	}

	//Copyright
	$ultra_print_copyright_color = get_theme_mod('ultra_print_copyright_color');

	if ( $ultra_print_copyright_color != '') {
		$ultra_print_custom_style .=' .site-footer p {';
			$ultra_print_custom_style .=' color: '.esc_attr($ultra_print_copyright_color).';';
		$ultra_print_custom_style .=' }';
	}

	$ultra_print_copyright_border_color = get_theme_mod('ultra_print_copyright_border_color');

	if ( $ultra_print_copyright_border_color != '') {
		$ultra_print_custom_style .=' .site-footer {';
			$ultra_print_custom_style .=' border-top-color: '.esc_attr($ultra_print_copyright_border_color).';';
		$ultra_print_custom_style .=' }';
	}

	$ultra_print_tbtext_color = get_theme_mod('ultra_print_tbtext_color');
	$ultra_print_tbbg_color = get_theme_mod('ultra_print_tbbg_color');
	if ( $ultra_print_tbtext_color != '') {
		$ultra_print_custom_style .=' .back-to-top {';
			$ultra_print_custom_style .=' color: '.esc_attr($ultra_print_tbtext_color).';  background-color: '.esc_attr($ultra_print_tbbg_color).';';
		$ultra_print_custom_style .=' }';
	}