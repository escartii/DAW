﻿$num = Get-Random -Minimum 1 -Maximum 49

Write-Host $num




