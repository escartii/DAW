﻿# Solicitar al usuario que ingrese una cadena
$cadena = Read-Host "Ingrese una cadena"

# Inicializar el contador de vocales
$contadorVocales = 0

# Recorrer cada carácter en la cadena
foreach ($caracter in $cadena.ToCharArray()) {
    # Verificar si el carácter es una vocal (mayúscula o minúscula)
    if ($caracter -match '[aeiouAEIOU]') {
        $contadorVocales++
    }
}

# Mostrar el resultado
Write-Host "Número de vocales en la cadena: $contadorVocales"
