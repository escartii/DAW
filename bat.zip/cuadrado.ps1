﻿# Solicitar el valor de 'n' al usuario
$n = Read-Host "Ingrese un número"

# Bucle para imprimir el dibujo
for ($i = 1; $i -le $n; $i++) {
    # Imprimir cada número repetido 5 veces
    1..5 | ForEach-Object { Write-Host $i -NoNewline; Write-Host " " -NoNewline }
    Write-Host # Salto de línea después de cada fila
}

Write-Host " "
# Bucle para imprimir el dibujo
for ($i = 4; $i -le $n; $i--) {
    # Imprimir cada número repetido 5 veces
    1..5 | ForEach-Object { Write-Host $i -NoNewline; Write-Host " " -NoNewline }
    Write-Host # Salto de línea después de cada fila

    if ($i -eq 1){
        exit
    }
}

