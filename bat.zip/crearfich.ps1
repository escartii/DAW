﻿Clear-Host
#Hecho por Alvaro Escarti

do {

    Write-Host "A. Crear Fichero
B. Copiar Fichero
C. Borrar fichero
D. Mover Fichero
E. Salir "

    $eleccion = Read-Host "Elige una opción"


    switch ($eleccion) {
        "A" {
            $fichero = Read-Host "Dime el nombre del fichero "
            $destino = Read-Host "Donde quieres guardar el fichero "
            New-Item -Path $destino\$fichero -ItemType File
            Write-Host "Fichero creado con exito"
            Write-Host " "
        }
        "B" {
            $origen = Read-Host "Dime cual es la ruta del fichero (incluye el fichero) "
            $destino = Read-Host "Donde quieres copiar el fichero? "
            Copy-Item -Path $origen -Destination $destino
            Write-Host "Fichero copiado con exito"
            Write-Host " "

        }
        "C" {
            $origen = Read-Host "Dime cual es la ruta del fichero (incluye el fichero) "
            Remove-Item -Path $origen
            Write-Host "Fichero borrado con exito"
            Write-Host " "

        }
        "D" {
            $origen = Read-Host "Dime cual es la ruta del fichero (incluye el fichero) "
            $destino = Read-Host "Donde quieres mover el fichero? "
            Move-Item -Path $origen -Destination $destino
            Write-Host "Fichero copiado con exito"
            Write-Host " "
        }
        "E"
            {
            exit
        }
        Default {
            Write-Host " "
            Write-Host "Opción inválida, vuelve a intentarlo: "
        }
    }

} while ($true);


