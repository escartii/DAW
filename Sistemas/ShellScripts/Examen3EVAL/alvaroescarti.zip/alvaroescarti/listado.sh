#!/bin/bash

#Alvaro Escarti :))

read -p "cuantos alumnos quieres premiar: " alumnos
fichero="alumnos.csv"
# compruebo que no hay mas de 30 alumnos
if [ $alumnos -gt 30 ]; then
    echo "no hay esta cantidad de alumnos"
else
# le paso el fichero alumnos csv y corto los campos requeridos y a la vez ordenados.
    sort -t ';' -k6,6nr -k3,3 -k2,2 -k5,5 < $fichero  | tr -s ';' ' ' | tail -n +2  | head -n "$alumnos" > FP_AÑO.txt
fi


exit 0

