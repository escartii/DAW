#!/bin/bash

#Alvaro Escarti :))

while true; do

    mostrar_piramide(){

        cat piramide.txt

    }

    sustituir(){
        cat piramide.txt | tr '*' 'caracter'
    }
  
    # Mostrar el menú
    echo "Selecciona una opción:"
    echo "1. Dibujar piramide en piramide.txt"
    echo "2. Mostrar piramide.txt"
    echo "3. Rotar piramide"
    echo "4. Contar astericos"
    echo "5. Sustituir *"
    echo "6. Salir"

    # Leer la opción del usuario
    read opcion

    # Realizar acciones según la opción seleccionada
    case $opcion in
        1)
            # mientras i sea mayor o igual 1 entra
            altura=$1
            for ((i = altura; i >= 1; i--)); do
                for ((j = 1; j <= (2 * altura - 1); j++)); do
                    if [ $((j + i)) -ge $((altura + 1)) ] && [ $((j - i)) -le $((altura - 1)) ]; then
                        echo -n "*"
                    else
                        echo -n " "
                    fi
                done
                #salto de linea
                echo
            done > piramide.txt
            ;;
        2)
            echo "Mostrar piramide"
            mostrar_piramide
            ;;
        3)
            echo "Rotar piramide"

            altura=$1
            anchura=$((2 * altura - 1))
            for ((i = 1; i <= altura; i++)); do
                for ((j = 1; j <= anchura; j++)); do
                    if [ $((j + i)) -ge $((altura + 1)) ] && [ $((j - i)) -le $((altura - 1)) ]; then
                        echo -n "*"
                    else
                        echo -n " "
                    fi
                done
            #salto de linea
            echo 
            done

            ;;
        4)
            echo "Contar astericos"
            contar=$(grep -o '*' piramide.txt | wc -w)
            echo $contar
            ;;
        5)
            echo "sustituir"
            read -p "que caracter quieres sustituir: " caracter
            sustituir

            ;;
        6)
            echo "Saliendo..."
            exit 0
            ;;
        *)
            echo "Opción no válida. Por favor, selecciona una opción del 1 al 5 o 6 para salir."
            ;;
    esac
done

exit 0