#!/bin/bash


#Alvaro Escarti :))

if [ "$EUID" -ne 0 ]; then
    echo "Por favor, ejecuta este script como sudo"
    exit 1
fi

# busco que existe el usuario en el etc passwd
read -p "dime tu usuario: " user
recuperar_usu=$(grep "^$user:" /etc/passwd | cut -d ":" -f6)
if [ -z $recuperar_usu ]; then
    echo "no existe el home del usuario: "$user
else
    # creo su directorio
    if [ ! -d "$recuperar_usu" ]; then
        mkdir -p $recuperar_usu
        chmod 755 $recuperar_usu
    fi
fi

exit 0

