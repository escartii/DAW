﻿# Solicitar al usuario que ingrese el año de nacimiento
$anioNacimiento = Read-Host "Ingrese el año de nacimiento (por ejemplo, 1990)"

# Verificar si la entrada es un número
if ($anioNacimiento -match '^\d+$') {
    # Calcular el signo del horóscopo chino
    $signo = ($anioNacimiento % 12)
    
    # Definir los signos del horóscopo chino
    $signosChinos = @("Mono", "Gallo", "Perro", "Cerdo", "Rata", "Buey", "Tigre", "Conejo", "Dragón", "Serpiente", "Caballo", "Cabra")

    # Mostrar el resultado
    Write-Host "Tu signo del horóscopo chino es $($signosChinos[$signo])"
} else {
    Write-Host "Por favor, ingresa un año de nacimiento válido."
}
