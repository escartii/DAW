﻿$altura = 5

for ($i = 1; $i -le $altura; $i++) {
    $linea = ""
    for ($j = 1; $j -le $i; $j++) {
        $linea += ($altura - $i + 1)
    }
    Write-Host $linea
}
