﻿[int]$dividiendo = Read-Host "Introduce el dividendo: "
[int]$divisor = Read-Host "Introduce un divisor: "


$cociente = $dividiendo / $divisor
$resto = $dividiendo % $divisor
[int][System.Math]::Floor($cociente)

Write-Host "el cociente es: " $cociente
$String = "String"

Write-Host "el resto es: " $resto
"MyString" -match "String^"

Write-Host (1,2,3 -contains 1)
exit