﻿

$suma = 5+6
Write-Host $suma

$nombre = 'ADD'
Write-Host $nombre*5

$fecha = [datetime]"09/20/2000"
Write-Host $fecha
$nombre = Read-Host "Como te llamas? "
Write-Host $nombre
$alvaro = "alvaro"
Write-Host $alvaro
Write-Host "Hola, Mundo"
Write-Host "Hola, $nombre" 
Write-Host "Hola, $alvaro" 
Write-Host $numero

$env.USERNAME

Write-Host $numero.GetType().Name