﻿# Obtener la ruta del escritorio del usuario
$desktopPath = [Environment]::GetFolderPath([Environment+SpecialFolder]::Desktop)

# Pedir al usuario la extensión de los archivos
$extension = Read-Host "Ingrese la extension de los archivos"

# Obtener todas las unidades lógicas
$drives = Get-PSDrive -PSProvider FileSystem

# Recorrer cada unidad lógica y buscar archivos con la extensión especificada
foreach ($drive in $drives) {
    $files = Get-ChildItem -Path $drive.Root -Recurse -File -Filter "*.$extension"
    
    # Escribir los nombres de los archivos encontrados en el archivo "listado.txt"
    $files | ForEach-Object {
        $_.FullName | Out-File -FilePath "$desktopPath\listado.txt" -Append
    }
}

Write-Host "El archivo 'listado.txt' ha sido creado en el escritorio con los nombres de los archivos encontrados."