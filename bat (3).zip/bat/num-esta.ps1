﻿# num-está.ps1

# Función para generar números aleatorios en un rango
function Generar-NumerosAleatorios ($min, $max, $cantidad) {
    $numeros = @()
    for ($i = 1; $i -le $cantidad; $i++) {
        $numeros += Get-Random -Minimum $min -Maximum $max
    }
    return $numeros
}

# Preguntar al usuario por el rango y la cantidad de números aleatorios
$minimo = Read-Host "Ingrese el valor mínimo del rango"
$maximo = Read-Host "Ingrese el valor máximo del rango"
$cantidad = Read-Host "Ingrese la cantidad de números a generar"

# Generar números aleatorios
$numerosGenerados = Generar-NumerosAleatorios -min $minimo -max $maximo -cantidad $cantidad

# Preguntar al usuario por un número
$numeroUsuario = Read-Host "Ingrese un número para verificar si está en la lista"
Write-Host $numerosGenerados
# Verificar si el número está en la lista generada
if ($numerosGenerados -contains $numeroUsuario) {
    Write-Host "El número $numeroUsuario está en la lista generada."
} else {
    Write-Host "El número $numeroUsuario no está en la lista generada."
}
