﻿[int]$num = Read-Host "introduce un numero: "
Write-Host $num


for ($i = 0; $i -le 10; $i++){
    $resultado =  $num * $i
    Write-Host $num * $i = $resultado
} 

